import React,{Component} from 'react';
import './App.css';

export default class Main extends Component{

    render(){
        return(<div style={{marginTop:'60px'}}>
                <div  className="row">
                   <b> <i className="fa fa-arrow-left"></i> Vendor Contracts > Fixed Price Contracts - English</b>
        <div className="row1">
                <button className="btn btn-default" style={{marginRight:'50px', width:'150px',backgroundColor:'lightgrey'}}>Cancel</button>
                <button className="btn btn-primary" style={{ width:'150px'}}>Save</button>
        </div>
                </div>
                <hr style={{backgroundColor:'lightGray',height:'1px'}}/>
<div className="row">
    <div className="col col-sm-12">
            <div className="col-sm-4" >
                <div className="col-sm-3" style={{backgroundColor:'white',height:'90px',borderRadius:'2px',fontSize:'12px'}}><h2>18</h2>
                Intents</div>
                <div className="col-sm-3" style={{backgroundColor:'white',height:'90px',borderRadius:'2px',fontSize:'12px'}}><h2>256</h2>
                Entities</div>
                <div className="col-sm-3" style={{backgroundColor:'white',height:'90px',borderRadius:'2px',fontSize:'12px'}}><h2>
                    12</h2>
                    Documents</div>
                <div className="col-sm-3" style={{backgroundColor:'white',height:'90px',borderRadius:'2px',fontSize:'12px'}}><h2>232</h2>
                Sentences Identified</div>

            </div>
            <div className="col-sm-4" style={{backgroundColor:'white',height:'90px'}}>Documents Status</div>
            <div className="col-sm-4" style={{backgroundColor:'white',height:'90px'}}>Assigne</div>
    </div>
    <div className="row">
        Basic Information
    </div>

</div>
        </div>);
    }
}