import React from 'react';
import logo from './logo.svg';
import './App.css';
import TopBar from './topBar';
import SideBar from './sideBar';
import Main from './main';
function App() {
  return (
    <div >
      <div  className="row">
      <TopBar/>
      </div>
      
      <div className="row">
      <div className="col-sm-1">
      <SideBar/>  
      </div>
      <div className="col-sm-10">
              <Main/>
      </div>
      </div>
     
      
    </div>
  );
}

export default App;
