import React,{Component} from 'react';


export default class x extends Component{

    render(){
        return(<div>
                <nav className="navbar navbar-inverse navbar-fixed-top">
                    <div className="container-fluid">
    <div className="navbar-header">
    <button type="button" className="navbar-toggle" data-toggle="collapse" >
        <span className="icon-bar"></span>
        <span className="icon-bar"></span>
        <span className="icon-bar"></span>
      </button>
      
    </div>
    <ul className="nav navbar-nav" style={{float:'right'}}>
      <li className="active"><a href="#"><i class="fa fa-search"></i></a></li>
      <li className="active"><select id="selectOp">
          <option>
            Select Project
          </option>
          </select>
          </li>
          <li>
          <a href="#" className="w3-bar-item w3-button"><i className="fa fa-bell"></i></a>
          </li>
          <li>
          <a href="#" className="w3-bar-item w3-button"><i className="fa fa-user-circle"></i></a>
          </li>
    </ul>
  </div>
</nav>
        </div>);
    }
}